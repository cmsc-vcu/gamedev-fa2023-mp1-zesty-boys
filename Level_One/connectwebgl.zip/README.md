# gamedev-fa2023-mp1
CMSC391/COAR463 Game Development - Minor Project 1

Great job on creating your own copy of the minor project 1 scaffold!

Be sure to review the resources on the Canvas site Week 6:

<https://virginiacommonwealth.instructure.com/courses/86151/modules>

To learn more about writing good README.md files, see:

<https://www.freecodecamp.org/news/how-to-write-a-good-readme-file/>

This is a scaffold project. I’ll be providing scaffolds throughout the
semester to get you working faster, and to make grading much easier for
the TA team.

Good luck!
